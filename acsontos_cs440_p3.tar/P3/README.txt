Code is written for JAVA output
